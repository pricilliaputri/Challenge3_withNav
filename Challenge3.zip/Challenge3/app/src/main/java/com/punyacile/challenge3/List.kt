package com.punyacile.challenge3

data class List(val kata : String)