package com.punyacile.challenge3

data class HurufList(val huruf : String)